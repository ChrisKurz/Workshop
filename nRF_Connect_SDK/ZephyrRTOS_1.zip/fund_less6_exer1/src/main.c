/*
 * Copyright (c) 2017 Linaro Limited
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr.h>
#include <device.h>
#include <drivers/gpio.h>
#include <sys/printk.h>
#include <sys/__assert.h>
#include <string.h>

/* size of stack area used by each thread */
#define STACKSIZE 1024

/* scheduling priority used by each thread */
#define THREAD0_PRIORITY 7
#define THREAD1_PRIORITY 7

void thread0(void)
{
	while (1) {
          printk("Hello, I am thread0\n");
	}
}

void thread1(void)
{
	while (1) {
          printk("Hello, I am thread1\n");
	}
}


//#define THREAD2_PRIORITY 7

//void thread2(void)
//{
//	while (1) {
//          printk("Hello, I am thread2\n");
//	}
//}

//K_THREAD_DEFINE(thread2_id, STACKSIZE, thread2, NULL, NULL, NULL,
//		THREAD2_PRIORITY, 0, 0);


K_THREAD_DEFINE(thread0_id, STACKSIZE, thread0, NULL, NULL, NULL,
		THREAD0_PRIORITY, 0, 0);
K_THREAD_DEFINE(thread1_id, STACKSIZE, thread1, NULL, NULL, NULL,
		THREAD1_PRIORITY, 0, 0);

